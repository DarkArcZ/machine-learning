from . import text_classification_sst_2

__all__ = ["text_classification_sst_2"]
