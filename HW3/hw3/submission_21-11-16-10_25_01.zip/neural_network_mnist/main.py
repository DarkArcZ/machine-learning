# When taking sqrt for initialization you might want to use math package,
# since torch.sqrt requires a tensor, and math.sqrt is ok with integer
import math
from typing import List

import matplotlib.pyplot as plt
import numpy as np
import torch
import seaborn as sns
from torch.distributions import Uniform
from torch.nn import Module
import torch.nn.functional as F
from torch.nn.parameter import Parameter
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from tqdm import tqdm

from utils import load_dataset, problem

sns.set()

class F1(Module):
    @problem.tag("hw3-A", start_line=1)
    def __init__(self, h: int, d: int, k: int):
        """Create a F1 model as described in pdf.

        Args:
            h (int): Hidden dimension.
            d (int): Input dimension/number of features.
            k (int): Output dimension/number of classes.
        """
        super().__init__()
        self.alpha0 = 1/np.sqrt(d)
        self.alpha1 = 1/np.sqrt(h)
        self.w0 = torch.FloatTensor(d, h).uniform_(-self.alpha0, self.alpha0)
        self.b0 = torch.FloatTensor(1, h).uniform_(-self.alpha0, self.alpha0)
        self.w1 = torch.FloatTensor(h, k).uniform_(-self.alpha1, self.alpha1)
        self.b1 = torch.FloatTensor(1, k).uniform_(-self.alpha1, self.alpha1)

        self.params = [self.w0, self.b0, self.w1, self.b1]
        for param in self.params:
            param.requires_grad = True

    @problem.tag("hw3-A")
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Pass input through F1 model.

        It should perform operation:
        W_1(sigma(W_0*x + b_0)) + b_1

        Args:
            x (torch.Tensor): FloatTensor of shape (n, d). Input data.

        Returns:
            torch.Tensor: LongTensor of shape (n, k). Prediction.
        """
        res = torch.matmul(x, self.w0) + self.b0
        res = F.relu(res)
        res = torch.matmul(res, self.w1) + self.b1
        return res



class F2(Module):
    @problem.tag("hw3-A", start_line=1)
    def __init__(self, h0: int, h1: int, d: int, k: int):
        """Create a F2 model as described in pdf.

        Args:
            h0 (int): First hidden dimension (between first and second layer).
            h1 (int): Second hidden dimension (between second and third layer).
            d (int): Input dimension/number of features.
            k (int): Output dimension/number of classes.
        """
        super().__init__()
        self.alpha0 = 1/np.sqrt(d)
        self.alpha1 = 1/np.sqrt(h)
        self.w0 = torch.FloatTensor(d, h0).uniform_(-self.alpha0, self.alpha0)
        self.b0 = torch.FloatTensor(1, h0).uniform_(-self.alpha0, self.alpha0)
        self.w1 = torch.FloatTensor(h1, h1).uniform_(-self.alpha1, self.alpha1)
        self.b1 = torch.FloatTensor(1, h1).uniform_(-self.alpha1, self.alpha1)
        self.w2 = torch.FloatTensor(h1, k).uniform_(-self.alpha1, self.alpha1)
        self.b2 = torch.FloatTensor(1, k).uniform_(-self.alpha1, self.alpha1) 

        self.params = [self.w0, self.b0, self.w1, self.b1, self.w2, self.b2]
        for param in self.params:
            param.requires_grad = True

    @problem.tag("hw3-A")
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Pass input through F2 model.

        It should perform operation:
        W_2(sigma(W_1(sigma(W_0*x + b_0)) + b_1) + b_2)

        Args:
            x (torch.Tensor): FloatTensor of shape (n, d). Input data.

        Returns:
            torch.Tensor: LongTensor of shape (n, k). Prediction.
        """
        res = torch.matmul(x, self.w0) + self.b0
        res = F.relu(res)
        res = torch.matmul(res, self.w1) + self.b1
        res = F.relu(res)
        res = torch.matmul(res, self.w2) + self.b2
        return res


@problem.tag("hw3-A")
def train(model: Module, optimizer: optim.Adam, train_loader: DataLoader) -> List[float]:
    """
    Train a model until it reaches 99% accuracy on train set, and return list of training crossentropy losses for each epochs.

    Args:
        model (Module): Model to train. Either F1, or F2 in this problem.
        optimizer (Adam): Optimizer that will adjust parameters of the model.
        train_loader (DataLoader): DataLoader with training data.
            You can iterate over it like a list, and it will produce tuples (x, y),
            where x is FloatTensor of shape (n, d) and y is LongTensor of shape (n,).

    Returns:
        List[float]: List containing average loss for each epoch.
    """
    losses = []
    acc = 0
    epochs = 0
        # for batch in tqdm(train_loader):
        #     print(batch.shape)
            # images, labels = batch
            # images, lavels = images, labels
            # images = images.view(-1, 784)
            # optimizer.zero_grad()
            # logits = model.forward(images)
            # preds = torch.argmax(logits, 1)
            # acc += torch.sum(preds == labels).items()
            # loss = F.cross_entropy(logits, labels)
            # loss_epoch += loss.items()
            # loss.backward()
            # optimizer.step()
        # print("Epoch", i)
        # print("Loss", loss_epoch/len(train_loader[0]))
        # print("Acc:", acc/len(train_loader[0]))
        # losses.append(loss_epoch/len(train_loader[0]))
        # if acc/len(train_loader[0])>0.99:
        #     break
    return losses



@problem.tag("hw3-A", start_line=5)
def main():
    """
    Main function of this problem.
    For both F1 and F2 models it should:
        1. Train a model
        2. Plot per epoch losses
        3. Report accuracy and loss on test set
        4. Report total number of parameters for each network

    Note that we provided you with code that loads MNIST and changes x's and y's to correct type of tensors.
    We strongly advise that you use torch functionality such as datasets, but as mentioned in the pdf you cannot use anything from torch.nn other than what is imported here.
    """
    (x, y), (x_test, y_test) = load_dataset("mnist")
    x = torch.from_numpy(x).float()
    y = torch.from_numpy(y).long()
    x_test = torch.from_numpy(x_test).float()
    y_test = torch.from_numpy(y_test).long()
    model1 = F1(64, 784, 10)
    print(F1.w0)
    # optimizer = optim.Adam(model1.params, lr=5e-3)
    # train(model1, optimizer, train_loader=(x,y))



if __name__ == "__main__":
    main()
